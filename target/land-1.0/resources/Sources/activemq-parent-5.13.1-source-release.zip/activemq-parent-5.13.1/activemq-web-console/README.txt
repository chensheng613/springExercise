
Welcome to the ActiveMQ Web Console

To run the console you must install a recent distro of Apache Maven
such as version 3.0.4 or later
	
		http://maven.apache.org/

You can then run the ActiveMQ Web Console via the following command.

	mvn jetty:run

